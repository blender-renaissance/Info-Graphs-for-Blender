bl_info = {
    "name": "SQL support for blender",
    "author": "Vikrant Jadhav, Blender Renaissance",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Renaissance tab",
    "description": "Quick Render Presets for Blender Renaissance Graphs.",
    "warning": "",
    "doc_url": "https://twitter.com/b3d_Renaissance",
    "category": "3D View",
}

__addon_enabled__ = True  # Set to True if you want the addon enabled by default

if __addon_enabled__:
    # Your addon code goes here
    pass

def unregister():
    # Your unregister logic goes here
    # This can include removing operators, panels, handlers, etc.
    print("MySQL addon is being unregistered.")

# Rest of your addon code...

if __name__ == "__main__":
    register()